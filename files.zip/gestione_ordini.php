<?php
require_once 'config.php';

// ─── LOGICA BACKEND ──────────────────────────────────────────────────────────

$pdo    = getConnection();
$action = $_GET['action'] ?? 'lista';
$errors = [];
$success = '';

// ── SALVA NUOVO ORDINE ───────────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action === 'aggiungi') {
    $id_cliente    = (int)($_POST['id_cliente'] ?? 0);
    $id_dipendente = (int)($_POST['id_dipendente'] ?? 0);
    $data_ordine   = trim($_POST['data_ordine'] ?? '');
    $data_arrivo   = trim($_POST['data_arrivo'] ?? '') ?: null;
    $prodotti_ids  = $_POST['prodotti'] ?? [];
    $quantita      = $_POST['quantita'] ?? [];

    if (!$id_cliente)    $errors[] = 'Seleziona un cliente.';
    if (!$id_dipendente) $errors[] = 'Seleziona un dipendente.';
    if (!$data_ordine)   $errors[] = 'Inserisci la data ordine.';
    if (empty($prodotti_ids)) $errors[] = 'Aggiungi almeno un prodotto.';

    if (empty($errors)) {
        try {
            $pdo->beginTransaction();

            $stmt = $pdo->prepare(
                "INSERT INTO ordini (ID_Cliente, ID_Dipendente, Data_Ordine, Data_Arrivo)
                 VALUES (?, ?, ?, ?)"
            );
            $stmt->execute([$id_cliente, $id_dipendente, $data_ordine, $data_arrivo]);
            $new_id = $pdo->lastInsertId();

            $stmtProd = $pdo->prepare(
                "INSERT INTO ordine_prodotti (ID_Ordine, ID_Prodotto, Quantita) VALUES (?, ?, ?)"
            );
            foreach ($prodotti_ids as $i => $pid) {
                $pid = (int)$pid;
                $qty = max(1, (int)($quantita[$i] ?? 1));
                if ($pid > 0) {
                    $stmtProd->execute([$new_id, $pid, $qty]);
                }
            }

            $pdo->commit();
            $success = "Ordine #$new_id creato con successo.";
            $action = 'lista';
        } catch (Exception $e) {
            $pdo->rollBack();
            $errors[] = 'Errore DB: ' . $e->getMessage();
        }
    }
}

// ── SALVA MODIFICA ORDINE ────────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action === 'modifica') {
    $id_ordine     = (int)($_POST['id_ordine'] ?? 0);
    $id_cliente    = (int)($_POST['id_cliente'] ?? 0);
    $id_dipendente = (int)($_POST['id_dipendente'] ?? 0);
    $data_ordine   = trim($_POST['data_ordine'] ?? '');
    $data_arrivo   = trim($_POST['data_arrivo'] ?? '') ?: null;
    $prodotti_ids  = $_POST['prodotti'] ?? [];
    $quantita      = $_POST['quantita'] ?? [];

    if (!$id_ordine)     $errors[] = 'ID ordine mancante.';
    if (!$id_cliente)    $errors[] = 'Seleziona un cliente.';
    if (!$id_dipendente) $errors[] = 'Seleziona un dipendente.';
    if (!$data_ordine)   $errors[] = 'Inserisci la data ordine.';
    if (empty($prodotti_ids)) $errors[] = 'Aggiungi almeno un prodotto.';

    if (empty($errors)) {
        try {
            $pdo->beginTransaction();

            $stmt = $pdo->prepare(
                "UPDATE ordini SET ID_Cliente=?, ID_Dipendente=?, Data_Ordine=?, Data_Arrivo=?
                 WHERE ID_Ordine=?"
            );
            $stmt->execute([$id_cliente, $id_dipendente, $data_ordine, $data_arrivo, $id_ordine]);

            $pdo->prepare("DELETE FROM ordine_prodotti WHERE ID_Ordine=?")->execute([$id_ordine]);

            $stmtProd = $pdo->prepare(
                "INSERT INTO ordine_prodotti (ID_Ordine, ID_Prodotto, Quantita) VALUES (?, ?, ?)"
            );
            foreach ($prodotti_ids as $i => $pid) {
                $pid = (int)$pid;
                $qty = max(1, (int)($quantita[$i] ?? 1));
                if ($pid > 0) {
                    $stmtProd->execute([$id_ordine, $pid, $qty]);
                }
            }

            $pdo->commit();
            $success = "Ordine #$id_ordine aggiornato con successo.";
            $action = 'lista';
        } catch (Exception $e) {
            $pdo->rollBack();
            $errors[] = 'Errore DB: ' . $e->getMessage();
        }
    }
}

// ── DATI PER LE VISTE ────────────────────────────────────────────────────────
$clienti    = $pdo->query("SELECT ID_Cliente, Nome_Azienda FROM clienti ORDER BY Nome_Azienda")->fetchAll();
$dipendenti = $pdo->query("SELECT ID_Dipendente, Nome, Cognome FROM dipendenti ORDER BY Cognome")->fetchAll();
$prodotti   = $pdo->query("SELECT ID_Prodotto, Desc_prodotto FROM prodotti ORDER BY Desc_prodotto")->fetchAll();

// Lista ordini con JOIN
$ordini = $pdo->query(
    "SELECT o.ID_Ordine, o.Data_Ordine, o.Data_Arrivo,
            c.Nome_Azienda,
            CONCAT(d.Nome,' ',d.Cognome) AS Dipendente,
            COUNT(op.ID_Prodotto) AS Num_Prodotti
     FROM ordini o
     LEFT JOIN clienti c    ON c.ID_Cliente    = o.ID_Cliente
     LEFT JOIN dipendenti d ON d.ID_Dipendente = o.ID_Dipendente
     LEFT JOIN ordine_prodotti op ON op.ID_Ordine = o.ID_Ordine
     GROUP BY o.ID_Ordine
     ORDER BY o.Data_Ordine DESC"
)->fetchAll();

// Dati ordine per modifica
$ordine_edit  = null;
$prodotti_edit = [];
if ($action === 'modifica' && isset($_GET['id'])) {
    $id_edit = (int)$_GET['id'];
    $ordine_edit = $pdo->prepare(
        "SELECT * FROM ordini WHERE ID_Ordine = ?"
    );
    $ordine_edit->execute([$id_edit]);
    $ordine_edit = $ordine_edit->fetch();

    $prodotti_edit = $pdo->prepare(
        "SELECT ID_Prodotto, Quantita FROM ordine_prodotti WHERE ID_Ordine = ?"
    );
    $prodotti_edit->execute([$id_edit]);
    $prodotti_edit = $prodotti_edit->fetchAll();
}

// ─── HTML ─────────────────────────────────────────────────────────────────────
?>
<!DOCTYPE html>
<html lang="it">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Gestione Ordini</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=DM+Mono:wght@300;400;500&family=Syne:wght@400;600;700;800&display=swap" rel="stylesheet">
<style>
  :root {
    --bg:        #0d0f14;
    --surface:   #14171f;
    --surface2:  #1c202c;
    --border:    #252a38;
    --accent:    #f5a623;
    --accent2:   #e07b00;
    --text:      #e8eaf0;
    --muted:     #6b7280;
    --green:     #34d399;
    --red:       #f87171;
    --blue:      #60a5fa;
    --radius:    6px;
  }

  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

  body {
    background: var(--bg);
    color: var(--text);
    font-family: 'DM Mono', monospace;
    font-size: 13px;
    min-height: 100vh;
  }

  /* ── HEADER ── */
  header {
    background: var(--surface);
    border-bottom: 1px solid var(--border);
    padding: 0 32px;
    display: flex;
    align-items: center;
    gap: 32px;
    height: 56px;
    position: sticky;
    top: 0;
    z-index: 100;
  }
  .logo {
    font-family: 'Syne', sans-serif;
    font-weight: 800;
    font-size: 17px;
    letter-spacing: -0.5px;
    color: var(--text);
  }
  .logo span { color: var(--accent); }
  nav a {
    color: var(--muted);
    text-decoration: none;
    font-size: 12px;
    letter-spacing: 0.08em;
    text-transform: uppercase;
    padding: 4px 0;
    border-bottom: 2px solid transparent;
    transition: color .15s, border-color .15s;
  }
  nav a:hover, nav a.active {
    color: var(--accent);
    border-bottom-color: var(--accent);
  }

  /* ── LAYOUT ── */
  main { max-width: 1100px; margin: 0 auto; padding: 36px 24px; }

  .page-title {
    font-family: 'Syne', sans-serif;
    font-weight: 700;
    font-size: 22px;
    letter-spacing: -0.5px;
    margin-bottom: 24px;
    display: flex;
    align-items: center;
    gap: 10px;
  }
  .page-title::before {
    content: '';
    display: block;
    width: 4px;
    height: 22px;
    background: var(--accent);
    border-radius: 2px;
  }

  /* ── ALERTS ── */
  .alert {
    padding: 12px 16px;
    border-radius: var(--radius);
    margin-bottom: 20px;
    font-size: 12px;
    line-height: 1.6;
    border-left: 3px solid;
  }
  .alert-error   { background: rgba(248,113,113,.08); border-color: var(--red);   color: var(--red); }
  .alert-success { background: rgba(52,211,153,.08);  border-color: var(--green); color: var(--green); }

  /* ── TABELLA ── */
  .card {
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: var(--radius);
    overflow: hidden;
  }
  .card-header {
    padding: 16px 20px;
    border-bottom: 1px solid var(--border);
    display: flex;
    align-items: center;
    justify-content: space-between;
  }
  .card-header h2 {
    font-family: 'Syne', sans-serif;
    font-size: 13px;
    font-weight: 700;
    letter-spacing: 0.06em;
    text-transform: uppercase;
    color: var(--muted);
  }

  table { width: 100%; border-collapse: collapse; }
  thead th {
    padding: 10px 16px;
    text-align: left;
    font-size: 10px;
    letter-spacing: 0.12em;
    text-transform: uppercase;
    color: var(--muted);
    background: var(--surface2);
    border-bottom: 1px solid var(--border);
    font-weight: 500;
  }
  tbody tr {
    border-bottom: 1px solid var(--border);
    transition: background .1s;
  }
  tbody tr:last-child { border-bottom: none; }
  tbody tr:hover { background: var(--surface2); }
  td {
    padding: 12px 16px;
    vertical-align: middle;
  }
  .badge {
    display: inline-block;
    padding: 2px 8px;
    border-radius: 20px;
    font-size: 10px;
    font-weight: 500;
    letter-spacing: 0.05em;
    background: rgba(96,165,250,.12);
    color: var(--blue);
    border: 1px solid rgba(96,165,250,.25);
  }
  .id-cell {
    color: var(--muted);
    font-size: 11px;
  }
  .empty-state {
    text-align: center;
    padding: 48px 16px;
    color: var(--muted);
  }
  .empty-state p { font-size: 13px; }

  /* ── FORM ── */
  .form-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 18px; }
  .form-group { display: flex; flex-direction: column; gap: 6px; }
  .form-group.full { grid-column: 1 / -1; }
  label {
    font-size: 10px;
    letter-spacing: 0.1em;
    text-transform: uppercase;
    color: var(--muted);
    font-weight: 500;
  }
  input, select {
    background: var(--surface2);
    border: 1px solid var(--border);
    border-radius: var(--radius);
    color: var(--text);
    padding: 9px 12px;
    font-family: 'DM Mono', monospace;
    font-size: 13px;
    outline: none;
    transition: border-color .15s;
    width: 100%;
  }
  input:focus, select:focus { border-color: var(--accent); }
  select option { background: var(--surface2); }

  /* ── PRODOTTI DINAMICI ── */
  .products-section {
    margin-top: 4px;
    border: 1px solid var(--border);
    border-radius: var(--radius);
    overflow: hidden;
  }
  .products-header {
    background: var(--surface2);
    padding: 10px 14px;
    font-size: 10px;
    letter-spacing: 0.1em;
    text-transform: uppercase;
    color: var(--muted);
    font-weight: 500;
    display: flex;
    align-items: center;
    justify-content: space-between;
  }
  #products-list { padding: 12px 14px; display: flex; flex-direction: column; gap: 8px; }
  .product-row {
    display: grid;
    grid-template-columns: 1fr 90px 36px;
    gap: 8px;
    align-items: center;
    animation: slideIn .15s ease;
  }
  @keyframes slideIn {
    from { opacity: 0; transform: translateY(-4px); }
    to   { opacity: 1; transform: translateY(0); }
  }
  .btn-remove {
    width: 32px; height: 32px;
    background: rgba(248,113,113,.1);
    border: 1px solid rgba(248,113,113,.2);
    border-radius: var(--radius);
    color: var(--red);
    cursor: pointer;
    font-size: 16px;
    display: flex; align-items: center; justify-content: center;
    transition: background .15s;
    flex-shrink: 0;
  }
  .btn-remove:hover { background: rgba(248,113,113,.2); }

  /* ── BUTTONS ── */
  .btn {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 8px 16px;
    border-radius: var(--radius);
    font-family: 'DM Mono', monospace;
    font-size: 12px;
    font-weight: 500;
    cursor: pointer;
    text-decoration: none;
    border: 1px solid transparent;
    transition: all .15s;
    letter-spacing: 0.03em;
  }
  .btn-primary {
    background: var(--accent);
    color: #0d0f14;
    border-color: var(--accent);
  }
  .btn-primary:hover { background: var(--accent2); border-color: var(--accent2); }
  .btn-secondary {
    background: transparent;
    color: var(--muted);
    border-color: var(--border);
  }
  .btn-secondary:hover { color: var(--text); border-color: var(--muted); }
  .btn-ghost {
    background: transparent;
    color: var(--blue);
    border-color: transparent;
    padding: 6px 10px;
    font-size: 11px;
  }
  .btn-ghost:hover { background: rgba(96,165,250,.08); }
  .btn-add-product {
    background: rgba(245,166,35,.07);
    color: var(--accent);
    border-color: rgba(245,166,35,.2);
    font-size: 11px;
    padding: 5px 12px;
  }
  .btn-add-product:hover { background: rgba(245,166,35,.14); }

  .form-actions {
    display: flex;
    gap: 10px;
    margin-top: 24px;
    padding-top: 20px;
    border-top: 1px solid var(--border);
  }

  /* ── DIVIDER ── */
  .section-divider {
    height: 1px;
    background: var(--border);
    margin: 28px 0;
  }

  /* ── STATO DATA ARRIVO ── */
  .date-arrived   { color: var(--green); }
  .date-pending   { color: var(--accent); }
  .date-none      { color: var(--muted); font-style: italic; }
</style>
</head>
<body>

<header>
  <div class="logo">GESTIONALE<span>.</span></div>
  <nav style="display:flex;gap:24px;">
    <a href="?action=lista"    class="<?= $action==='lista'    ? 'active' : '' ?>">Ordini</a>
    <a href="?action=aggiungi" class="<?= $action==='aggiungi' ? 'active' : '' ?>">+ Nuovo Ordine</a>
  </nav>
</header>

<main>

<?php if (!empty($errors)): ?>
  <div class="alert alert-error">
    <?= implode('<br>', array_map('htmlspecialchars', $errors)) ?>
  </div>
<?php endif; ?>

<?php if ($success): ?>
  <div class="alert alert-success">✓ <?= htmlspecialchars($success) ?></div>
<?php endif; ?>


<!-- ══════════════════════════════════════════════════════ LISTA ORDINI ══ -->
<?php if ($action === 'lista'): ?>

<div class="page-title">Tutti gli Ordini</div>

<div class="card">
  <div class="card-header">
    <h2>Registro ordini &mdash; <?= count($ordini) ?> record</h2>
    <a href="?action=aggiungi" class="btn btn-primary">+ Nuovo ordine</a>
  </div>

  <?php if (empty($ordini)): ?>
    <div class="empty-state">
      <p>Nessun ordine trovato. <a href="?action=aggiungi" style="color:var(--accent);text-decoration:none;">Crea il primo.</a></p>
    </div>
  <?php else: ?>
    <table>
      <thead>
        <tr>
          <th>#</th>
          <th>Cliente</th>
          <th>Dipendente</th>
          <th>Data Ordine</th>
          <th>Data Arrivo</th>
          <th>Prodotti</th>
          <th></th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($ordini as $o): ?>
        <tr>
          <td class="id-cell"><?= $o['ID_Ordine'] ?></td>
          <td><?= htmlspecialchars($o['Nome_Azienda'] ?? '—') ?></td>
          <td><?= htmlspecialchars($o['Dipendente'] ?? '—') ?></td>
          <td><?= htmlspecialchars($o['Data_Ordine'] ?? '—') ?></td>
          <td>
            <?php if ($o['Data_Arrivo']): ?>
              <?php $arrived = strtotime($o['Data_Arrivo']) <= time(); ?>
              <span class="<?= $arrived ? 'date-arrived' : 'date-pending' ?>">
                <?= htmlspecialchars($o['Data_Arrivo']) ?>
              </span>
            <?php else: ?>
              <span class="date-none">n/d</span>
            <?php endif; ?>
          </td>
          <td><span class="badge"><?= $o['Num_Prodotti'] ?> pz.</span></td>
          <td>
            <a href="?action=modifica&id=<?= $o['ID_Ordine'] ?>" class="btn btn-ghost">✎ Modifica</a>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  <?php endif; ?>
</div>


<!-- ═════════════════════════════════════════════════ AGGIUNGI ORDINE ══ -->
<?php elseif ($action === 'aggiungi'): ?>

<div class="page-title">Nuovo Ordine</div>

<div class="card">
  <div class="card-header"><h2>Inserimento ordine</h2></div>
  <div style="padding:24px;">
    <form method="POST" action="?action=aggiungi">

      <div class="form-grid">

        <div class="form-group">
          <label>Cliente</label>
          <select name="id_cliente" required>
            <option value="">— seleziona —</option>
            <?php foreach ($clienti as $c): ?>
              <option value="<?= $c['ID_Cliente'] ?>"
                <?= (isset($_POST['id_cliente']) && $_POST['id_cliente'] == $c['ID_Cliente']) ? 'selected' : '' ?>>
                <?= htmlspecialchars($c['Nome_Azienda']) ?>
              </option>
            <?php endforeach; ?>
          </select>
        </div>

        <div class="form-group">
          <label>Dipendente</label>
          <select name="id_dipendente" required>
            <option value="">— seleziona —</option>
            <?php foreach ($dipendenti as $d): ?>
              <option value="<?= $d['ID_Dipendente'] ?>"
                <?= (isset($_POST['id_dipendente']) && $_POST['id_dipendente'] == $d['ID_Dipendente']) ? 'selected' : '' ?>>
                <?= htmlspecialchars($d['Cognome'] . ' ' . $d['Nome']) ?>
              </option>
            <?php endforeach; ?>
          </select>
        </div>

        <div class="form-group">
          <label>Data Ordine</label>
          <input type="date" name="data_ordine" required
                 value="<?= htmlspecialchars($_POST['data_ordine'] ?? date('Y-m-d')) ?>">
        </div>

        <div class="form-group">
          <label>Data Arrivo Prevista</label>
          <input type="date" name="data_arrivo"
                 value="<?= htmlspecialchars($_POST['data_arrivo'] ?? '') ?>">
        </div>

        <div class="form-group full">
          <label>Prodotti</label>
          <div class="products-section">
            <div class="products-header">
              <span>Righe prodotto</span>
              <button type="button" class="btn btn-add-product" onclick="addProductRow()">+ aggiungi riga</button>
            </div>
            <div id="products-list">
              <!-- riga di default -->
            </div>
          </div>
        </div>

      </div>

      <div class="form-actions">
        <button type="submit" class="btn btn-primary">Salva Ordine</button>
        <a href="?action=lista" class="btn btn-secondary">Annulla</a>
      </div>

    </form>
  </div>
</div>


<!-- ══════════════════════════════════════════════════ MODIFICA ORDINE ══ -->
<?php elseif ($action === 'modifica' && $ordine_edit): ?>

<div class="page-title">Modifica Ordine #<?= $ordine_edit['ID_Ordine'] ?></div>

<div class="card">
  <div class="card-header"><h2>Aggiorna ordine</h2></div>
  <div style="padding:24px;">
    <form method="POST" action="?action=modifica">
      <input type="hidden" name="id_ordine" value="<?= $ordine_edit['ID_Ordine'] ?>">

      <div class="form-grid">

        <div class="form-group">
          <label>Cliente</label>
          <select name="id_cliente" required>
            <option value="">— seleziona —</option>
            <?php foreach ($clienti as $c): ?>
              <option value="<?= $c['ID_Cliente'] ?>"
                <?= ($c['ID_Cliente'] == $ordine_edit['ID_Cliente']) ? 'selected' : '' ?>>
                <?= htmlspecialchars($c['Nome_Azienda']) ?>
              </option>
            <?php endforeach; ?>
          </select>
        </div>

        <div class="form-group">
          <label>Dipendente</label>
          <select name="id_dipendente" required>
            <option value="">— seleziona —</option>
            <?php foreach ($dipendenti as $d): ?>
              <option value="<?= $d['ID_Dipendente'] ?>"
                <?= ($d['ID_Dipendente'] == $ordine_edit['ID_Dipendente']) ? 'selected' : '' ?>>
                <?= htmlspecialchars($d['Cognome'] . ' ' . $d['Nome']) ?>
              </option>
            <?php endforeach; ?>
          </select>
        </div>

        <div class="form-group">
          <label>Data Ordine</label>
          <input type="date" name="data_ordine" required
                 value="<?= htmlspecialchars($ordine_edit['Data_Ordine'] ?? '') ?>">
        </div>

        <div class="form-group">
          <label>Data Arrivo Prevista</label>
          <input type="date" name="data_arrivo"
                 value="<?= htmlspecialchars($ordine_edit['Data_Arrivo'] ?? '') ?>">
        </div>

        <div class="form-group full">
          <label>Prodotti</label>
          <div class="products-section">
            <div class="products-header">
              <span>Righe prodotto</span>
              <button type="button" class="btn btn-add-product" onclick="addProductRow()">+ aggiungi riga</button>
            </div>
            <div id="products-list">
              <!-- righe caricate via JS -->
            </div>
          </div>
        </div>

      </div>

      <div class="form-actions">
        <button type="submit" class="btn btn-primary">Aggiorna Ordine</button>
        <a href="?action=lista" class="btn btn-secondary">Annulla</a>
      </div>

    </form>
  </div>
</div>

<?php endif; ?>

</main>

<!-- ─── JAVASCRIPT ──────────────────────────────────────────────────────────── -->
<script>
// Prodotti disponibili iniettati da PHP
const PRODOTTI = <?= json_encode(array_map(fn($p) => [
    'id'   => $p['ID_Prodotto'],
    'desc' => $p['Desc_prodotto'],
], $prodotti), JSON_UNESCAPED_UNICODE) ?>;

// Righe preesistenti per la modifica
const PRODOTTI_EDIT = <?= json_encode(array_map(fn($p) => [
    'id'  => $p['ID_Prodotto'],
    'qty' => $p['Quantita'],
], $prodotti_edit ?? []), JSON_UNESCAPED_UNICODE) ?>;

let rowIndex = 0;

function buildSelect(selectedId = '') {
    let opts = '<option value="">— prodotto —</option>';
    PRODOTTI.forEach(p => {
        const sel = p.id == selectedId ? ' selected' : '';
        opts += `<option value="${p.id}"${sel}>${escHtml(p.desc)}</option>`;
    });
    return opts;
}

function escHtml(str) {
    return String(str)
        .replace(/&/g,'&amp;').replace(/</g,'&lt;')
        .replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

function addProductRow(selectedId = '', qty = 1) {
    const list = document.getElementById('products-list');
    const div  = document.createElement('div');
    div.className = 'product-row';
    div.innerHTML = `
      <select name="prodotti[]">${buildSelect(selectedId)}</select>
      <input type="number" name="quantita[]" value="${qty}" min="1" placeholder="Qtà">
      <button type="button" class="btn-remove" onclick="this.closest('.product-row').remove()">×</button>
    `;
    list.appendChild(div);
    rowIndex++;
}

// Init: carica righe preesistenti oppure una riga vuota
document.addEventListener('DOMContentLoaded', () => {
    if (PRODOTTI_EDIT.length > 0) {
        PRODOTTI_EDIT.forEach(p => addProductRow(p.id, p.qty));
    } else {
        addProductRow();
    }
});
</script>

</body>
</html>
